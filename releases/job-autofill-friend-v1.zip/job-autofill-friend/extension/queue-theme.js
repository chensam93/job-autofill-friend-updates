/**
 * Queue console appearance. Dark is the default; light is stored only after
 * the user toggles it. This file is a blocking classic script in <head> so a
 * saved light preference applies before first paint (extension CSP forbids
 * inline scripts).
 */
(function () {
  var KEY = "jaf-queue-theme";

  function isLight() {
    return document.documentElement.getAttribute("data-theme") === "light";
  }

  function apply(theme) {
    var root = document.documentElement;
    var meta = document.querySelector('meta[name="color-scheme"]');
    if (theme === "light") {
      root.setAttribute("data-theme", "light");
      if (meta) meta.setAttribute("content", "light");
    } else {
      root.removeAttribute("data-theme");
      if (meta) meta.setAttribute("content", "dark");
    }
    try {
      localStorage.setItem(KEY, theme);
    } catch {
      // Private mode can refuse localStorage; the in-page theme still applies.
    }
    syncToggle();
  }

  function syncToggle() {
    var btn = document.getElementById("theme-toggle");
    if (!btn) return;
    var light = isLight();
    var label = light ? "Switch to dark appearance" : "Switch to light appearance";
    btn.setAttribute("aria-pressed", light ? "false" : "true");
    btn.setAttribute("title", label);
    btn.setAttribute("aria-label", label);
  }

  try {
    if (localStorage.getItem(KEY) === "light") apply("light");
  } catch {
    // Stay on the CSS default (dark).
  }

  document.addEventListener("click", function (event) {
    var target = event.target;
    if (!target || typeof target.closest !== "function") return;
    if (!target.closest("#theme-toggle")) return;
    apply(isLight() ? "dark" : "light");
  });

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", syncToggle);
  } else {
    syncToggle();
  }
})();
