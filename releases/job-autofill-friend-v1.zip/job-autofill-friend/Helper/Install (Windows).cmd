@echo off
powershell -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-windows.ps1"
pause
