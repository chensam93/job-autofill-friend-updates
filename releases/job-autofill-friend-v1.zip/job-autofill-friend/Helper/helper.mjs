#!/usr/bin/env node
/**
 * Job Autofill helper for a packaged copy (the friend's build).
 *
 * It answers the extension's AI requests through the Claude Code app that the
 * person signed in to with their own Claude plan, so the AI uses that plan
 * instead of a pay-per-use API key. That is all it does: no files besides its
 * own settings and a one-line-per-request log, no Gmail, no profile.
 *
 *   node helper.mjs serve   run the server (the login task or launch agent does this)
 *   node helper.mjs pair    print the pairing code, making one the first time
 *   node helper.mjs status  say whether Claude Code can be found
 *   node helper.mjs set-extension <folder>   the installer records the extension folder
 *   node helper.mjs update  check for a newer copy now (it also checks by itself)
 *
 * It also keeps the extension up to date (updater.mjs): every few hours it
 * looks for a newer copy published by Samuel and swaps it into her folder.
 *
 * The server listens only on 127.0.0.1:4174, answers only callers that send
 * the pairing code, and runs Claude Code with every tool turned off, in an
 * empty temporary folder, with the person's customizations skipped.
 */
import { spawn } from "node:child_process";
import { createUpdater } from "./updater.mjs";
import { randomBytes, timingSafeEqual } from "node:crypto";
import { appendFileSync, existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, statSync, writeFileSync } from "node:fs";
import http from "node:http";
import { homedir, tmpdir } from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

export const HELPER_VERSION = "2";
export const PORT = Number(process.env.JAF_FRIEND_HELPER_PORT) || 4174;
const MAX_BODY_BYTES = 512 * 1024;
const MAX_OUTPUT_BYTES = 2 * 1024 * 1024;
const RUN_TIMEOUT_MS = 115_000;
const MAX_RUNNING = 2;
const MAX_WAITING = 8;
const EFFORTS = new Set(["low", "medium", "high"]);

export function dataDir(env = process.env, platform = process.platform) {
  if (env.JAF_FRIEND_HELPER_DIR) return env.JAF_FRIEND_HELPER_DIR;
  if (platform === "win32") return path.join(env.LOCALAPPDATA || path.join(homedir(), "AppData", "Local"), "JobAutofillHelper");
  if (platform === "darwin") return path.join(homedir(), "Library", "Application Support", "JobAutofillHelper");
  return path.join(env.XDG_DATA_HOME || path.join(homedir(), ".local", "share"), "job-autofill-helper");
}

function settingsPath(dir) { return path.join(dir, "settings.json"); }

/** The code the person pastes on the profile page. Made once, kept after. */
export function pairingCode(dir = dataDir()) {
  try {
    const saved = JSON.parse(readFileSync(settingsPath(dir), "utf8"));
    if (typeof saved.pairingCode === "string" && /^[A-Z2-9]{4}-[A-Z2-9]{4}$/.test(saved.pairingCode)) return saved.pairingCode;
  } catch { /* first run */ }
  const letters = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const bytes = randomBytes(8);
  const raw = Array.from(bytes, (byte) => letters[byte % letters.length]).join("");
  const code = `${raw.slice(0, 4)}-${raw.slice(4)}`;
  mkdirSync(dir, { recursive: true });
  writeFileSync(settingsPath(dir), JSON.stringify({ pairingCode: code }, null, 2));
  return code;
}

function log(dir, line) {
  try {
    const file = path.join(dir, "helper.log");
    if (existsSync(file) && statSync(file).size > 512 * 1024) rmSync(file);
    appendFileSync(file, `${new Date().toISOString()} ${line}\n`);
  } catch { /* logging is best effort */ }
}

/** Where Claude Code's own installers put it, then PATH. */
export function findClaude(env = process.env, platform = process.platform) {
  if (env.JAF_CLAUDE_PATH) return existsSync(env.JAF_CLAUDE_PATH) ? env.JAF_CLAUDE_PATH : null;
  const home = homedir();
  const pathDirs = (env.PATH || env.Path || "").split(path.delimiter).filter(Boolean);
  const candidates = platform === "win32"
    ? [path.join(home, ".local", "bin", "claude.exe"),
      ...pathDirs.map((dir) => path.join(dir, "claude.exe")),
      ...pathDirs.map((dir) => path.join(dir, "claude.cmd")),
      path.join(env.APPDATA || path.join(home, "AppData", "Roaming"), "npm", "claude.cmd")]
    : [path.join(home, ".local", "bin", "claude"), path.join(home, ".claude", "local", "claude"),
      "/opt/homebrew/bin/claude", "/usr/local/bin/claude", ...pathDirs.map((dir) => path.join(dir, "claude"))];
  return candidates.find((candidate) => { try { return statSync(candidate).isFile(); } catch { return false; } }) ?? null;
}

export function claudeArgs(systemFile, effort) {
  return ["-p", "--output-format", "json",
    // No tools at all, none of the person's plugins, hooks, MCP servers or
    // CLAUDE.md files, and no saved conversation.
    "--tools", "", "--safe-mode", "--strict-mcp-config", "--disable-slash-commands", "--no-session-persistence",
    "--system-prompt-file", systemFile, "--effort", effort];
}

function quoteForCmd(value) {
  return /^[\w\-.:\\/=]+$/.test(value) ? value : `"${value.replace(/"/g, '""')}"`;
}

/**
 * Runs one request through Claude Code. Resolves to { ok, text } or
 * { ok:false, status, error, detail }.
 */
export function runClaude({ system, prompt, effort }, { signal, env = process.env, platform = process.platform } = {}) {
  const executable = findClaude(env, platform);
  if (!executable) return Promise.resolve({ ok: false, status: 503, error: "claude_not_found" });
  const workdir = mkdtempSync(path.join(tmpdir(), "jaf-helper-"));
  const systemFile = path.join(workdir, "system.txt");
  writeFileSync(systemFile, system);
  const args = claudeArgs(systemFile, effort);
  // Her plan, not an API key someone left in the environment.
  const childEnv = { ...env };
  delete childEnv.ANTHROPIC_API_KEY;
  delete childEnv.ANTHROPIC_AUTH_TOKEN;
  const npmShim = platform === "win32" && executable.toLowerCase().endsWith(".cmd");
  const child = npmShim
    ? spawn(env.ComSpec || "cmd.exe", ["/d", "/s", "/c", `"${[executable, ...args].map(quoteForCmd).join(" ")}"`],
      { cwd: workdir, env: childEnv, windowsHide: true, windowsVerbatimArguments: true })
    : spawn(executable, args, { cwd: workdir, env: childEnv, windowsHide: true });
  return new Promise((resolve) => {
    let stdout = "", stderr = "", settled = false;
    const finish = (result) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      signal?.removeEventListener("abort", onAbort);
      try { child.kill(); } catch { /* already gone */ }
      rmSync(workdir, { recursive: true, force: true });
      resolve(result);
    };
    const onAbort = () => finish({ ok: false, status: 499, error: "cancelled" });
    const timer = setTimeout(() => finish({ ok: false, status: 504, error: "timeout" }), RUN_TIMEOUT_MS);
    signal?.addEventListener("abort", onAbort);
    child.stdout.on("data", (chunk) => { if (stdout.length < MAX_OUTPUT_BYTES) stdout += chunk; });
    child.stderr.on("data", (chunk) => { if (stderr.length < 64 * 1024) stderr += chunk; });
    child.on("error", () => finish({ ok: false, status: 503, error: "claude_not_startable" }));
    child.on("close", () => finish(readClaudeOutput(stdout, stderr)));
    child.stdin.on("error", () => {});
    child.stdin.end(prompt);
  });
}

/** Claude Code's --output-format json result, as this helper's answer. */
export function readClaudeOutput(stdout, stderr = "") {
  let result = null;
  try {
    const parsed = JSON.parse(stdout.trim().split("\n").filter(Boolean).pop() ?? "");
    result = Array.isArray(parsed) ? parsed.findLast?.((item) => item?.type === "result") ?? null : parsed;
  } catch { /* not JSON */ }
  const said = `${typeof result?.result === "string" ? result.result : ""} ${stderr}`.slice(0, 600);
  if (!result || result.is_error || typeof result.result !== "string") {
    if (/log ?in|logged in|sign ?in|authenticat|\/login|oauth|credential/i.test(said)) return { ok: false, status: 401, error: "not_signed_in", detail: said.trim().slice(0, 200) };
    if (/usage limit|rate limit|limit reached|resets? at|too many requests|overloaded/i.test(said)) return { ok: false, status: 429, error: "usage_limit", detail: said.trim().slice(0, 200) };
    return { ok: false, status: 502, error: "claude_failed", detail: said.trim().slice(0, 200) };
  }
  return { ok: true, text: result.result };
}

function sameCode(given, expected) {
  const a = Buffer.from(String(given ?? "").trim().toUpperCase());
  const b = Buffer.from(expected);
  return a.length === b.length && timingSafeEqual(a, b);
}

export function createHelperServer({ code, dir = dataDir(), run = runClaude, updater = null } = {}) {
  let running = 0;
  const waiting = [];
  const slot = () => new Promise((resolve, reject) => {
    if (running < MAX_RUNNING) { running++; resolve(); return; }
    if (waiting.length >= MAX_WAITING) { reject(Error("busy")); return; }
    waiting.push(resolve);
  });
  const release = () => { const next = waiting.shift(); if (next) next(); else running--; };

  return http.createServer((req, res) => {
    const origin = String(req.headers.origin ?? "");
    const reply = (status, body) => {
      res.writeHead(status, {
        "Content-Type": "application/json",
        ...(origin.startsWith("chrome-extension://") ? { "Access-Control-Allow-Origin": origin, Vary: "Origin" } : {}),
      });
      res.end(JSON.stringify(body));
    };
    // Only the extension may call, and only with the code shown at install.
    if (!origin.startsWith("chrome-extension://")) return reply(403, { ok: false, error: "not_extension" });
    if (req.method === "OPTIONS") {
      res.writeHead(204, { "Access-Control-Allow-Origin": origin, "Access-Control-Allow-Methods": "GET, POST",
        "Access-Control-Allow-Headers": "Content-Type, X-JAF-Pair", "Access-Control-Max-Age": "600", Vary: "Origin" });
      return res.end();
    }
    const url = new URL(req.url ?? "/", "http://127.0.0.1");
    // Updates work before she pairs (or if she never uses AI): the extension
    // only says which version it runs and reads back update news.
    if (url.pathname === "/update/running" && req.method === "POST") {
      let raw = "";
      req.on("data", (chunk) => { if (raw.length < 4096) raw += chunk; });
      req.on("end", () => {
        let version = null;
        try { version = JSON.parse(raw)?.version ?? null; } catch { /* no body */ }
        reply(200, { ok: true, helperVersion: HELPER_VERSION, ...(updater ? updater.heard(Number.isInteger(version) ? version : null) : { updatesOn: false }) });
      });
      return;
    }
    if (url.pathname === "/update/status" && req.method === "GET") {
      return reply(200, { ok: true, helperVersion: HELPER_VERSION, ...(updater ? updater.status() : { updatesOn: false }) });
    }
    if (!sameCode(req.headers["x-jaf-pair"], code)) return reply(401, { ok: false, error: "wrong_pairing_code" });
    if (req.method === "GET" && url.pathname === "/status") {
      return reply(200, { ok: true, version: HELPER_VERSION, claudeFound: Boolean(findClaude()) });
    }
    if (req.method !== "POST" || url.pathname !== "/ask") return reply(404, { ok: false, error: "not_found" });
    const chunks = [];
    let size = 0;
    req.on("data", (chunk) => {
      size += chunk.length;
      if (size > MAX_BODY_BYTES) { reply(413, { ok: false, error: "too_large" }); req.destroy(); return; }
      chunks.push(chunk);
    });
    req.on("end", async () => {
      if (size > MAX_BODY_BYTES) return;
      let body;
      try { body = JSON.parse(Buffer.concat(chunks).toString("utf8")); } catch { return reply(400, { ok: false, error: "bad_json" }); }
      const system = typeof body?.system === "string" ? body.system : "";
      const prompt = typeof body?.prompt === "string" ? body.prompt : "";
      const effort = EFFORTS.has(body?.effort) ? body.effort : "low";
      if (!prompt.trim()) return reply(400, { ok: false, error: "empty_prompt" });
      try { await slot(); } catch { return reply(429, { ok: false, error: "busy" }); }
      const controller = new AbortController();
      res.on("close", () => { if (!res.writableEnded) controller.abort(); });
      const started = Date.now();
      try {
        const result = await run({ system, prompt, effort }, { signal: controller.signal });
        log(dir, `ask ${result.ok ? "ok" : result.error} ${Date.now() - started}ms`);
        if (res.writableEnded || res.destroyed) return;
        if (result.ok) reply(200, { ok: true, text: result.text });
        else reply(result.status ?? 502, { ok: false, error: result.error, ...(result.detail ? { detail: result.detail } : {}) });
      } finally {
        release();
      }
    });
  });
}

/**
 * After the updater replaced this helper's files: run the new ones. Windows
 * starts a fresh copy (its scheduled task does not restart a clean exit); a
 * Mac's launch agent restarts a helper that exits with an error code.
 */
function restartSelf(server) {
  let done = false;
  const go = () => {
    if (done) return;
    done = true;
    if (process.platform === "win32") {
      spawn(process.execPath, [fileURLToPath(import.meta.url), "serve"], { detached: true, stdio: "ignore", windowsHide: true }).unref();
      process.exit(0);
    }
    process.exit(75);
  };
  server.close(go);
  server.closeAllConnections?.();
  setTimeout(go, 5000).unref();
}

async function main(command) {
  const dir = dataDir();
  if (command === "pair") {
    console.log(pairingCode(dir));
    return;
  }
  if (command === "status") {
    const found = findClaude();
    console.log(found ? `Claude Code: ${found}` : "Claude Code: not found");
    process.exitCode = found ? 0 : 1;
    return;
  }
  const updater = createUpdater({ dir, helperDir: path.dirname(fileURLToPath(import.meta.url)), log: (line) => log(dir, line) });
  if (command === "set-extension") {
    const ok = updater.setExtensionDir(process.argv[3] ?? "");
    console.log(ok ? "Automatic updates: on" : "Automatic updates: off (the extension folder was not found next to the Helper folder)");
    return;
  }
  if (command === "update") {
    console.log(JSON.stringify(await updater.check()));
    return;
  }
  if (command === "selftest") {
    // A new helper proves it loads before it replaces this one.
    console.log(typeof createHelperServer === "function" && typeof updater.check === "function" ? "selftest ok" : "selftest failed");
    return;
  }
  if (command === "serve") {
    const code = pairingCode(dir);
    const server = createHelperServer({ code, dir, updater });
    let tries = 0;
    server.on("error", (error) => {
      // Just after a self-update the old helper may still hold the port.
      if (error.code === "EADDRINUSE" && ++tries < 10) {
        setTimeout(() => server.listen(PORT, "127.0.0.1"), 3000);
        return;
      }
      log(dir, `listen failed: ${error.code ?? error.message}`);
      process.exit(1);
    });
    server.listen(PORT, "127.0.0.1", () => log(dir, `listening on 127.0.0.1:${PORT}`));
    updater.start({ onHelperChanged: () => restartSelf(server) });
    return;
  }
  console.log("Usage: node helper.mjs serve | pair | status | set-extension <folder> | update");
  process.exitCode = 2;
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) await main(process.argv[2]);
