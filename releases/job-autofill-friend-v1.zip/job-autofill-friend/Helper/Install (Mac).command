#!/bin/bash
# Installs the Job Autofill helper for this Mac user: copies it to
# ~/Library/Application Support/JobAutofillHelper, starts it at every login
# (a launch agent), and prints the pairing code for the profile page.
set -euo pipefail
cd "$(dirname "$0")"
TARGET="$HOME/Library/Application Support/JobAutofillHelper"
LABEL="com.jobautofill.helper"
PLIST="$HOME/Library/LaunchAgents/$LABEL.plist"
export PATH="$HOME/.local/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"

NODE="$(command -v node || true)"
if [ -z "$NODE" ]; then
  echo; echo "Node.js is not installed. Install the LTS version from https://nodejs.org, then run this again."; echo; exit 1
fi
if ! JAF_FRIEND_HELPER_DIR="$TARGET" "$NODE" helper.mjs status >/dev/null; then
  echo
  echo "Claude Code is not installed. Open Terminal and run:"
  echo
  echo "    curl -fsSL https://claude.ai/install.sh | bash"
  echo
  echo "Then type  claude  and sign in with your Claude account. Quit and run this again."
  echo; exit 1
fi

mkdir -p "$TARGET" "$HOME/Library/LaunchAgents"
cp helper.mjs updater.mjs "$TARGET/"
xattr -d com.apple.quarantine "$TARGET/helper.mjs" "$TARGET/updater.mjs" 2>/dev/null || true

cat > "$PLIST" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>$LABEL</string>
  <key>ProgramArguments</key><array>
    <string>$NODE</string><string>$TARGET/helper.mjs</string><string>serve</string>
  </array>
  <key>EnvironmentVariables</key><dict>
    <key>PATH</key><string>$HOME/.local/bin:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin</string>
  </dict>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><dict><key>SuccessfulExit</key><false/></dict>
  <key>ThrottleInterval</key><integer>30</integer>
  <key>StandardErrorPath</key><string>$TARGET/launchd.log</string>
</dict></plist>
PLIST

launchctl bootout "gui/$(id -u)/$LABEL" 2>/dev/null || true
launchctl bootstrap "gui/$(id -u)" "$PLIST"

CODE="$("$NODE" "$TARGET/helper.mjs" pair)"
# Automatic updates: the extension folder that sits next to this Helper folder.
UPDATES="$(JAF_FRIEND_HELPER_DIR="$TARGET" "$NODE" "$TARGET/helper.mjs" set-extension "$(cd .. && pwd)/extension" || true)"
UP=no
for _ in $(seq 1 20); do
  if (exec 3<>/dev/tcp/127.0.0.1/4174) 2>/dev/null; then UP=yes; break; fi
  sleep 0.5
done
echo
if [ "$UP" = yes ]; then echo "The helper is running and will start again each time you log in."
else echo "The helper is installed but did not answer yet. Restart the Mac if the profile page cannot reach it."; fi
echo
case "$UPDATES" in
  *": on") echo "Automatic updates are on: new versions install by themselves." ;;
  *) echo "Automatic updates are off: the extension folder was not found next to this Helper folder. Unzip the whole copy first, then run this again from there." ;;
esac
echo
echo "Your pairing code:"
echo
echo "    $CODE"
echo
echo "In Chrome, open Job Autofill's profile page (the person icon in the popup), go to AI,"
echo "choose \"Claude app (helper)\", paste this code and press Connect."
echo
