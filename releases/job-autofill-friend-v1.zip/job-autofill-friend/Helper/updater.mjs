/**
 * Keeps a packaged copy of Job Autofill (the friend's build) up to date.
 *
 * Runs inside the helper (helper.mjs serve). At start and every few hours it
 * reads latest.json from the public update repo. When that names a newer
 * version it downloads the zip, checks its size and SHA-256 against
 * latest.json, unpacks only the extension (and the helper's own two files) to
 * a staging folder, checks the manifest and the version inside, and copies it
 * over the extension folder she loaded in Chrome. The folder as it was is kept
 * first, so a bad version can be put back.
 *
 * The extension notices the new build stamp on disk and reloads itself when
 * no fill or batch runs (build-freshness.ts). It then tells the helper which
 * version it runs (POST /update/running). If Chrome has been open for an hour
 * after a swap and the extension never once reported, the new version is taken
 * to have failed to load: the previous folder goes back and that version is
 * never installed again. A version listed as withdrawn in latest.json is put
 * back the same way.
 *
 * It only ever writes inside the extension folder (recorded by the installer,
 * and only if it looks like this extension) and the helper's own folder. Her
 * profile lives in Chrome's storage, not in these files, so it is untouched.
 */
import { spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
import { cpSync, existsSync, mkdirSync, readdirSync, readFileSync, renameSync, rmSync, statSync, writeFileSync } from "node:fs";
import path from "node:path";
import { inflateRawSync } from "node:zlib";

export const UPDATE_BASE = process.env.JAF_FRIEND_UPDATE_BASE
  || "https://raw.githubusercontent.com/chensam93/job-autofill-friend-updates/main/";
const CHECK_EVERY_MS = 4 * 60 * 60 * 1000;
const FIRST_CHECK_MS = 60 * 1000;
const WATCH_EVERY_MS = 5 * 60 * 1000;
/** Chrome-open time after a swap with no word from the extension before rolling back. */
const SILENT_CHROME_MS = 60 * 60 * 1000;
const MAX_ZIP_BYTES = 40 * 1024 * 1024;
const ZIP_ROOT = "job-autofill-friend/";
const HELPER_FILES = ["helper.mjs", "updater.mjs"];

// ---------- small pieces ----------

const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    table[n] = c >>> 0;
  }
  return table;
})();

/** CRC-32 as zip uses it (zlib.crc32 is missing from older Node 20 releases). */
export function crc32(data) {
  let crc = 0xffffffff;
  for (let i = 0; i < data.length; i++) crc = CRC_TABLE[(crc ^ data[i]) & 0xff] ^ (crc >>> 8);
  return (crc ^ 0xffffffff) >>> 0;
}

/**
 * Reads a zip into [{ name, data }]. Refuses anything odd: encryption, zip64,
 * names that climb out of the folder, a bad checksum.
 */
export function readZip(buffer) {
  let eocd = -1;
  for (let i = buffer.length - 22; i >= Math.max(0, buffer.length - 22 - 65535); i--) {
    if (buffer.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  }
  if (eocd < 0) throw Error("zip_unreadable");
  const count = buffer.readUInt16LE(eocd + 10);
  let at = buffer.readUInt32LE(eocd + 16);
  const entries = [];
  for (let i = 0; i < count; i++) {
    if (buffer.readUInt32LE(at) !== 0x02014b50) throw Error("zip_unreadable");
    const flags = buffer.readUInt16LE(at + 8);
    const method = buffer.readUInt16LE(at + 10);
    const crc = buffer.readUInt32LE(at + 16);
    const compressedSize = buffer.readUInt32LE(at + 20);
    const size = buffer.readUInt32LE(at + 24);
    const nameLength = buffer.readUInt16LE(at + 28);
    const extraLength = buffer.readUInt16LE(at + 30);
    const commentLength = buffer.readUInt16LE(at + 32);
    const localAt = buffer.readUInt32LE(at + 42);
    const name = buffer.subarray(at + 46, at + 46 + nameLength).toString("utf8");
    at += 46 + nameLength + extraLength + commentLength;
    if (flags & 1) throw Error("zip_encrypted");
    if (name.endsWith("/")) continue;
    if (!safeName(name)) throw Error("zip_bad_name");
    const dataAt = localAt + 30 + buffer.readUInt16LE(localAt + 26) + buffer.readUInt16LE(localAt + 28);
    const raw = buffer.subarray(dataAt, dataAt + compressedSize);
    const data = method === 0 ? Buffer.from(raw) : method === 8 ? inflateRawSync(raw) : null;
    if (!data) throw Error("zip_method");
    if (data.length !== size || crc32(data) !== crc) throw Error("zip_corrupt");
    entries.push({ name, data });
  }
  return entries;
}

function safeName(name) {
  if (!name || name.includes("\\") || name.includes("\0") || name.startsWith("/") || /^[a-zA-Z]:/.test(name)) return false;
  return name.split("/").every((part) => part !== ".." && part !== ".");
}

function readJson(file) {
  try { return JSON.parse(readFileSync(file, "utf8")); } catch { return null; }
}

function listFiles(dir, base = dir) {
  const out = [];
  for (const entry of readdirSync(dir)) {
    const full = path.join(dir, entry);
    if (statSync(full).isDirectory()) out.push(...listFiles(full, base));
    else out.push(path.relative(base, full));
  }
  return out;
}

/** The version a folder holds, from its friend-version.json; 0 when unknown. */
export function folderVersion(extensionDir) {
  const info = readJson(path.join(extensionDir, "friend-version.json"));
  return Number.isInteger(info?.version) ? info.version : 0;
}

/** True when the folder is a loaded copy of this extension, so writing there is safe. */
export function looksLikeOurExtension(extensionDir) {
  if (!extensionDir || !path.isAbsolute(extensionDir)) return false;
  const manifest = readJson(path.join(extensionDir, "manifest.json"));
  return manifest?.name === "Job Autofill" && manifest?.manifest_version === 3
    && existsSync(path.join(extensionDir, "dist", "background.js"));
}

function chromeRunning(platform = process.platform) {
  try {
    if (platform === "win32") {
      const out = spawnSync("tasklist", ["/FI", "IMAGENAME eq chrome.exe", "/NH"], { encoding: "utf8", windowsHide: true, timeout: 10_000 });
      return /chrome\.exe/i.test(out.stdout ?? "");
    }
    const out = spawnSync("pgrep", ["-x", platform === "darwin" ? "Google Chrome" : "chrome"], { encoding: "utf8", timeout: 10_000 });
    return out.status === 0;
  } catch {
    return false;
  }
}

// ---------- the updater ----------

/**
 * One updater per helper. `fetchImpl`, `now` and `isChromeRunning` are
 * swapped in by the smoke test.
 */
export function createUpdater({ dir, base = UPDATE_BASE, fetchImpl = fetch, now = () => Date.now(),
  isChromeRunning = chromeRunning, helperDir = null, log = () => {} } = {}) {
  const stateFile = path.join(dir, "update-state.json");
  const previousDir = path.join(dir, "previous", "extension");
  const stagingDir = path.join(dir, "staging");

  const read = () => readJson(stateFile) ?? {};
  const write = (state) => {
    mkdirSync(dir, { recursive: true });
    writeFileSync(`${stateFile}.tmp`, JSON.stringify(state, null, 2));
    renameSync(`${stateFile}.tmp`, stateFile);
  };
  const update = (patch) => { const next = { ...read(), ...patch }; write(next); return next; };
  let busy = false;

  /** Copies `fromDir` over `toDir`: new and changed files first, the build stamp last, then strays removed. */
  function overwrite(fromDir, toDir) {
    const files = listFiles(fromDir);
    const last = new Set([path.join("dist", "build-stamp.json"), "friend-version.json"]);
    for (const file of [...files.filter((f) => !last.has(f)), ...files.filter((f) => last.has(f))]) {
      mkdirSync(path.dirname(path.join(toDir, file)), { recursive: true });
      cpSync(path.join(fromDir, file), path.join(toDir, file), { force: true });
    }
    const keep = new Set(files);
    for (const file of listFiles(toDir)) if (!keep.has(file)) rmSync(path.join(toDir, file), { force: true });
  }

  function rollBack(reason) {
    const state = read();
    const extensionDir = state.extensionDir;
    if (!looksLikeOurExtension(extensionDir) || !looksLikeOurExtension(previousDir)) {
      update({ pending: null, lastError: `rollback_impossible:${reason}` });
      return false;
    }
    const bad = folderVersion(extensionDir);
    overwrite(previousDir, extensionDir);
    const restored = folderVersion(extensionDir);
    log(`update: rolled back v${bad} to v${restored} (${reason})`);
    update({
      pending: null,
      bad: [...new Set([...(state.bad ?? []), bad])],
      lastRollback: { from: bad, to: restored, reason, at: new Date(now()).toISOString() },
      lastError: `rolled_back:${reason}`,
    });
    return true;
  }

  /** Reads latest.json; on a newer version, installs it. Returns what happened. */
  async function check() {
    if (busy) return { result: "busy" };
    busy = true;
    try {
      return await checkInner();
    } catch (error) {
      const message = String(error?.message ?? error).slice(0, 120);
      log(`update: check failed ${message}`);
      update({ lastCheckAt: new Date(now()).toISOString(), lastCheckOk: false, lastError: message });
      return { result: "error", error: message };
    } finally {
      busy = false;
      rmSync(stagingDir, { recursive: true, force: true });
    }
  }

  async function checkInner() {
    const state = read();
    const extensionDir = state.extensionDir;
    if (!looksLikeOurExtension(extensionDir)) {
      update({ lastCheckAt: new Date(now()).toISOString(), lastCheckOk: false, lastError: "no_extension_folder" });
      return { result: "no_extension_folder" };
    }
    const response = await fetchImpl(`${base}latest.json?t=${Math.floor(now() / 60000)}`, { cache: "no-store" });
    if (!response.ok) throw Error(`latest_http_${response.status}`);
    const latest = await response.json();
    if (!Number.isInteger(latest?.version) || typeof latest.zip !== "string" || !/^[0-9a-f]{64}$/.test(latest.sha256 ?? "")
      || !safeName(latest.zip) || !Number.isInteger(latest.size)) throw Error("latest_malformed");
    const installed = folderVersion(extensionDir);
    const seen = { version: latest.version, publishedAt: latest.publishedAt ?? null, notes: latest.notes ?? "" };
    update({ lastCheckAt: new Date(now()).toISOString(), lastCheckOk: true, lastError: null, latest: seen });

    // A version Samuel pulled: put the one before it back, if that is what was kept.
    const withdrawn = Array.isArray(latest.withdrawn) ? latest.withdrawn : [];
    if (withdrawn.includes(installed) && looksLikeOurExtension(previousDir)
      && !withdrawn.includes(folderVersion(previousDir))) {
      rollBack("withdrawn");
      return { result: "rolled_back", version: folderVersion(extensionDir) };
    }
    if (latest.version <= installed) return { result: "current", version: installed };
    if ((read().bad ?? []).includes(latest.version) || withdrawn.includes(latest.version)) return { result: "skipped_bad", version: latest.version };
    if (latest.size > MAX_ZIP_BYTES) throw Error("zip_too_large");

    const zipResponse = await fetchImpl(`${base}${latest.zip}`, { cache: "no-store" });
    if (!zipResponse.ok) throw Error(`zip_http_${zipResponse.status}`);
    const zip = Buffer.from(await zipResponse.arrayBuffer());
    if (zip.length !== latest.size) throw Error("zip_incomplete");
    if (createHash("sha256").update(zip).digest("hex") !== latest.sha256) throw Error("zip_checksum");

    // Unpack only the extension and the helper's own files.
    rmSync(stagingDir, { recursive: true, force: true });
    const stagedExtension = path.join(stagingDir, "extension");
    const stagedHelper = path.join(stagingDir, "helper");
    for (const { name, data } of readZip(zip)) {
      if (!name.startsWith(ZIP_ROOT)) continue;
      const inner = name.slice(ZIP_ROOT.length);
      let target = null;
      if (inner.startsWith("extension/")) target = path.join(stagedExtension, inner.slice("extension/".length));
      else if (HELPER_FILES.some((file) => inner === `Helper/${file}`)) target = path.join(stagedHelper, inner.slice("Helper/".length));
      if (!target) continue;
      mkdirSync(path.dirname(target), { recursive: true });
      writeFileSync(target, data);
    }
    if (!looksLikeOurExtension(stagedExtension)) throw Error("zip_not_extension");
    if (folderVersion(stagedExtension) !== latest.version) throw Error("zip_version_mismatch");

    // Keep the folder as it is now, then put the new one in place.
    rmSync(path.join(dir, "previous"), { recursive: true, force: true });
    mkdirSync(previousDir, { recursive: true });
    overwrite(extensionDir, previousDir);
    try {
      overwrite(stagedExtension, extensionDir);
    } catch (error) {
      overwrite(previousDir, extensionDir);
      throw Error(`swap_failed_${error?.code ?? "write"}`);
    }
    log(`update: installed v${latest.version} over v${installed}`);
    update({
      pending: { version: latest.version, from: installed, swappedAt: new Date(now()).toISOString(), chromeOpenMs: 0, heard: false },
      lastUpdate: { version: latest.version, from: installed, at: new Date(now()).toISOString(), notes: latest.notes ?? "" },
    });
    const helperChanged = helperDir ? replaceHelperFiles(stagedHelper) : false;
    return { result: "updated", version: latest.version, from: installed, helperChanged };
  }

  /** New helper files: tried first (`selftest`), then copied over this helper's own. */
  function replaceHelperFiles(stagedHelper) {
    const changed = HELPER_FILES.filter((file) => {
      const fresh = path.join(stagedHelper, file);
      if (!existsSync(fresh)) return false;
      const current = path.join(helperDir, file);
      return !existsSync(current) || !readFileSync(fresh).equals(readFileSync(current));
    });
    if (changed.length === 0 || HELPER_FILES.some((file) => !existsSync(path.join(stagedHelper, file)))) return false;
    const trial = spawnSync(process.execPath, [path.join(stagedHelper, "helper.mjs"), "selftest"],
      { encoding: "utf8", timeout: 30_000, windowsHide: true, env: { ...process.env, JAF_FRIEND_HELPER_DIR: path.join(stagingDir, "selftest") } });
    if (trial.status !== 0 || !/selftest ok/.test(trial.stdout ?? "")) {
      log("update: new helper failed its self-test; keeping this one");
      return false;
    }
    for (const file of HELPER_FILES) cpSync(path.join(stagedHelper, file), path.join(helperDir, file), { force: true });
    log("update: helper files replaced; restarting");
    return true;
  }

  /** The extension says which version it runs (called on its start and every few minutes). */
  function heard(version) {
    const state = update({ lastReportAt: new Date(now()).toISOString(), lastReportVersion: Number.isInteger(version) ? version : null });
    if (state.pending) {
      if (version === state.pending.version) {
        log(`update: extension runs v${version}`);
        update({ pending: null });
      } else if (!state.pending.heard) {
        update({ pending: { ...state.pending, heard: true } });
      }
    }
    return status();
  }

  /** Every few minutes: count Chrome-open time while a swap waits for word from the extension. */
  function watch(stepMs = WATCH_EVERY_MS) {
    const state = read();
    const pending = state.pending;
    if (!pending) return null;
    if (pending.heard || (state.lastReportAt && state.lastReportAt > pending.swappedAt)) return null;
    if (!isChromeRunning()) return null;
    const chromeOpenMs = (pending.chromeOpenMs ?? 0) + stepMs;
    if (chromeOpenMs < SILENT_CHROME_MS) {
      update({ pending: { ...pending, chromeOpenMs } });
      return null;
    }
    return rollBack("never_loaded") ? "rolled_back" : null;
  }

  function status() {
    const state = read();
    return {
      updatesOn: looksLikeOurExtension(state.extensionDir),
      installed: state.extensionDir ? folderVersion(state.extensionDir) : 0,
      latest: state.latest ?? null,
      lastCheckAt: state.lastCheckAt ?? null,
      lastCheckOk: state.lastCheckOk ?? null,
      lastError: state.lastError ?? null,
      lastUpdate: state.lastUpdate ?? null,
      lastRollback: state.lastRollback ?? null,
      pending: state.pending ? { version: state.pending.version } : null,
    };
  }

  /** Records the folder the installer found next to the Helper folder. */
  function setExtensionDir(extensionDir) {
    const resolved = path.resolve(extensionDir);
    if (!looksLikeOurExtension(resolved)) return false;
    update({ extensionDir: resolved });
    return true;
  }

  /** Starts the timers; `onHelperChanged` restarts the helper after it replaced itself. */
  function start({ onHelperChanged = () => {} } = {}) {
    const run = () => check().then((outcome) => { if (outcome?.helperChanged) onHelperChanged(); }).catch(() => {});
    const first = setTimeout(run, FIRST_CHECK_MS);
    const every = setInterval(run, CHECK_EVERY_MS);
    const watcher = setInterval(() => { try { watch(); } catch { /* next time */ } }, WATCH_EVERY_MS);
    for (const timer of [first, every, watcher]) timer.unref?.();
    return () => { clearTimeout(first); clearInterval(every); clearInterval(watcher); };
  }

  return { check, heard, watch, status, setExtensionDir, rollBack, start, stateFile, previousDir };
}
