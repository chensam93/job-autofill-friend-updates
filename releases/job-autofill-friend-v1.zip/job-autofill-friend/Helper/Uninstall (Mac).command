#!/bin/bash
# Removes the Job Autofill helper for this Mac user.
LABEL="com.jobautofill.helper"
launchctl bootout "gui/$(id -u)/$LABEL" 2>/dev/null || true
rm -f "$HOME/Library/LaunchAgents/$LABEL.plist"
rm -rf "$HOME/Library/Application Support/JobAutofillHelper"
echo
echo "The helper is removed. On the profile page, choose a different AI option or leave AI off."
echo "Claude Code itself is still installed; remove it separately if you no longer want it."
echo
