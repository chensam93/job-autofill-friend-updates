# Removes the Job Autofill helper for this Windows user.
$ErrorActionPreference = 'SilentlyContinue'
$TaskName = 'Job Autofill Helper'
$Target = Join-Path $env:LOCALAPPDATA 'JobAutofillHelper'

Stop-ScheduledTask -TaskName $TaskName
Unregister-ScheduledTask -TaskName $TaskName -Confirm:$false
Get-CimInstance Win32_Process -Filter "Name = 'node.exe'" |
    Where-Object { $_.CommandLine -like '*JobAutofillHelper*helper.mjs*' } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force }
Start-Sleep -Milliseconds 500
Remove-Item -LiteralPath $Target -Recurse -Force

Write-Host ''
Write-Host 'The helper is removed. On the profile page, choose a different AI option or leave AI off.'
Write-Host 'Claude Code itself is still installed; remove it separately if you no longer want it.'
Write-Host ''
