# Installs the Job Autofill helper for this Windows user: copies it to
# %LOCALAPPDATA%\JobAutofillHelper, starts it at every sign-in, and prints the
# pairing code to paste on the extension's profile page. No admin rights.
$ErrorActionPreference = 'Stop'
$TaskName = 'Job Autofill Helper'
$Target = Join-Path $env:LOCALAPPDATA 'JobAutofillHelper'

function Stop-WithMessage([string]$Message) {
    Write-Host ''
    Write-Host $Message -ForegroundColor Yellow
    Write-Host ''
    exit 1
}

$node = (Get-Command node -ErrorAction SilentlyContinue).Source
if (-not $node -and (Test-Path 'C:\Program Files\nodejs\node.exe')) { $node = 'C:\Program Files\nodejs\node.exe' }
if (-not $node) {
    Stop-WithMessage "Node.js is not installed. Install the LTS version from https://nodejs.org, then run this again."
}

$env:JAF_FRIEND_HELPER_DIR = $Target
$found = & $node (Join-Path $PSScriptRoot 'helper.mjs') status
if ($LASTEXITCODE -ne 0) {
    Stop-WithMessage ("Claude Code is not installed. Open PowerShell and run:`n`n    irm https://claude.ai/install.ps1 | iex`n`n" +
        "Then type  claude  and sign in with your Claude account. Close that window and run this again.")
}

New-Item -ItemType Directory -Path $Target -Force | Out-Null
foreach ($file in 'helper.mjs', 'updater.mjs') {
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot $file) -Destination (Join-Path $Target $file) -Force
}

# Stop an older copy before starting this one.
Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue | Stop-ScheduledTask -ErrorAction SilentlyContinue
Get-CimInstance Win32_Process -Filter "Name = 'node.exe'" -ErrorAction SilentlyContinue |
    Where-Object { $_.CommandLine -like '*JobAutofillHelper*helper.mjs*' } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }

$user = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
$helper = Join-Path $Target 'helper.mjs'
$command = "& '$($node -replace "'", "''")' '$($helper -replace "'", "''")' serve"
$action = New-ScheduledTaskAction -Execute 'powershell.exe' `
    -Argument "-NoLogo -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -Command `"$command`""
$trigger = New-ScheduledTaskTrigger -AtLogOn -User $user
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable `
    -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Days 3650) `
    -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1)
$principal = New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive -RunLevel Limited
Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $trigger -Settings $settings -Principal $principal `
    -Description 'Lets the Job Autofill extension use Claude Code with your own Claude plan. Listens only on this computer.' -Force | Out-Null
Start-ScheduledTask -TaskName $TaskName

$code = (& $node $helper pair).Trim()
# Automatic updates: the extension folder that sits next to this Helper folder.
$extensionFolder = Join-Path (Split-Path $PSScriptRoot -Parent) 'extension'
$updates = (& $node $helper set-extension $extensionFolder | Out-String).Trim()
$up = $false
for ($i = 0; $i -lt 20 -and -not $up; $i++) {
    Start-Sleep -Milliseconds 500
    $up = [bool](Get-NetTCPConnection -LocalAddress 127.0.0.1 -LocalPort 4174 -State Listen -ErrorAction SilentlyContinue)
}

Write-Host ''
if ($up) { Write-Host 'The helper is running and will start again each time you sign in.' -ForegroundColor Green }
else { Write-Host 'The helper is installed but did not answer yet. Restart the computer if the profile page cannot reach it.' -ForegroundColor Yellow }
Write-Host ''
if ($updates -like '*: on') { Write-Host 'Automatic updates are on: new versions install by themselves.' -ForegroundColor Green }
else { Write-Host 'Automatic updates are off: the extension folder was not found next to this Helper folder. Unzip the whole copy first, then run this again from there.' -ForegroundColor Yellow }
Write-Host ''
Write-Host 'Your pairing code:'
Write-Host ''
Write-Host "    $code" -ForegroundColor Cyan
Write-Host ''
Write-Host 'In Chrome, open Job Autofill''s profile page (the person icon in the popup), go to AI,'
Write-Host 'choose "Claude app (helper)", paste this code and press Connect.'
Write-Host ''
